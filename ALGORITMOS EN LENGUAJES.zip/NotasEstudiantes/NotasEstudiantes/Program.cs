﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace NotasEstudiantes
{
    public  class Program
    {
        
        static void Main(string[] args)
        {
            int def = 0;
            int reg = 0;
            int bue = 0;
            int exc = 0;
            int contador = 0;

            double[] Notas = new double[20];
            Random aleatorio = new Random();

            for (int i = 0; i < Notas.Length; i++)
            {
                double randomFloat = (double)aleatorio.Next(0 , 5);

                Notas[i] = aleatorio.Next(0, 5);
            }

            Console.WriteLine("----------------->>>-[Notas Estudiantes]-<<<-----------------");
            for (int i = 0; i < Notas.Length; i++)
            {
                contador++;
                Console.WriteLine("Estudiante N°"+contador+": "+Notas[i]);
            }

            for (int i = 0; i < Notas.Length; i++)
            {
                if (Notas[i] >= 0 & Notas[i] <= 1)
                {
                    def++;

                }
                else
                {
                    if (Notas[i] > 1 & Notas[i] <= 3)
                    {
                        reg++;
                    }
                    else
                    {
                        if (Notas[i] > 3 & Notas[i] <= 4)
                        {
                            bue++;
                        }
                        else
                        {
                            if (Notas[i] > 4 & Notas[i] <= 5)
                            {
                                exc++;
                            }
                        }

                    }
                }
            }

            
            Console.WriteLine("--->> pulse una tecla para ver el resultado");
            Console.ReadKey();
            Console.Clear();
          
            Console.WriteLine("|->>>-[Resultados]-<<<-|:");
            Console.WriteLine("  ___________________");
            Console.WriteLine(" |\\ _________________\\");
            Console.WriteLine(" |\\| ->[RESULTADOS]<- |");
            Console.WriteLine(" |\\|------------------|");
            Console.WriteLine(" |\\| Deficientes |: " + def + " |");
            Console.WriteLine(" |\\|-------------|----|");
            Console.WriteLine(" |\\| Regulares   |: " + reg + " |");
            Console.WriteLine(" |\\|-------------|----|");
            Console.WriteLine(" |\\| Buenos      |: " + bue + " |");
            Console.WriteLine(" |\\|-------------|----|");
            Console.WriteLine(" |\\| Excelentes  |: " + exc + " |");
            Console.WriteLine("  \\|__________________|");


        }
    }
}
