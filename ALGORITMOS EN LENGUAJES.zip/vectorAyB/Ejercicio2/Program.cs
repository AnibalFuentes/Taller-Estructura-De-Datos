﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Ejercicio2
{
    public class Program
    {
        private int[] A;//Declaramos un vector A
        private int[] B;//Declaramos un vector B
        private int[] C;//Declaramos un vector C
        private int[] D;
        private int[] E;
        private int[] F;

        Random r = new Random();
      
        static void Main(string[] args)
        {
            Program pv = new Program();
            pv.Menu();
            
        }
        public void Menu()
        {
            Console.Write("Ingrese el tamaño de los vectores : ");


            int n = int.Parse(Console.ReadLine());
            int opcion;

            A = new int[n];
            B = new int[n];
            C = new int[n];
            D = new int[n];

            do
            {

                Console.WriteLine("--------------------------------------");
                Console.WriteLine("---------> Escoga una de las opciones:");

                Console.WriteLine("1- LLENAR EL VECTOR A");
                Console.WriteLine("2- LLENAR EL VECTOR B");
                Console.WriteLine("3- SUMA DE LOS VECTORES A Y B");
                Console.WriteLine("4- RESTA DE LOS VECTORES A Y B");
                Console.WriteLine("5- NUMEROS DE AMBOS VECOTRES");
                Console.WriteLine("6- ORDEN INVERSO VECTOR A");
                Console.WriteLine("7- MOSTRAR EL VECTOR A, B, C O D");
                Console.WriteLine("8- SALIR ");
                Console.WriteLine("--------------------------------------");
                Console.Write("Escoja una opción: ");
                opcion = int.Parse(Console.ReadLine());
                Console.Clear();
                switch (opcion)
                {
                    case 1:
                        Console.WriteLine("----------------------------");
                        Console.WriteLine("OPCION 1: LLENAR EL VECTOR A");
                        for (int i = 0; i < A.Length; i++)
                        {


                            A[i] = r.Next(-100, 100);
                            Console.WriteLine((i + 1) + "." + A[i]);


                        }
                        Console.WriteLine("Acción realizada.");
                        Console.WriteLine(" ");
                        Console.ReadKey();
                        Console.Clear();
                        break;
                        
                    case 2:
                        Console.WriteLine("----------------------------");
                        Console.WriteLine("OPCION 2: LLENAR EL VECTOR B");
                        for (int j = 0; j < B.Length; j++)
                        {

                            B[j] = r.Next(-100, 100);
                            Console.WriteLine((j + 1) + "." + B[j]);

                        }
                        Console.WriteLine("Acción realizada.");
                        Console.WriteLine(" ");
                        Console.ReadKey();
                        Console.Clear();
                        break;
                    case 3:
                        Console.WriteLine("----------------------------");
                        Console.WriteLine("OPCION 3: SUMAR VECTOR A Y B");
                        for (int i = 0; i < A.Length; i++)
                        {
                            C[i] = A[i] + B[i];
                        }
                        Console.WriteLine("La suma de los vectores es: ");
                        for (int i = 0; i < A.Length; i++)
                        {
                            Console.WriteLine((i + 1) + "." + C[i]);
                        }

                        Console.WriteLine("Suma realizada.");
                        Console.WriteLine(" ");
                        Console.ReadKey();
                        Console.Clear();
                        break;
                    case 4:
                        Console.WriteLine("----------------------------");
                        Console.WriteLine("OPCION 4: RESTAR VECTOR A Y B");
                        for (int i = 0; i < A.Length; i++)
                        {
                            D[i] = A[i] - B[i];
                        }
                        Console.WriteLine("La resta de los vecores es: ");
                        for (int i = 0; i < A.Length; i++)
                        {
                            Console.WriteLine((i + 1) + "." + D[i]);
                        }
                        Console.WriteLine("Resta realizada.");
                        Console.WriteLine(" ");
                        Console.ReadKey();
                        Console.Clear();
                        break;
                    case 5:
                        Console.WriteLine("----------------------------");
                        Console.WriteLine("OPCION 5: UNIR VECTOR A Y B");
                        int array1OriginalLength = A.Length;
                        Array.Resize<int>(ref A, array1OriginalLength + B.Length);
                        Array.Copy(B, 0, A, array1OriginalLength, B.Length);
                        foreach (var e in A)
                        {
                            Console.WriteLine(e);
                        }
                        Console.WriteLine("Unión realizada.");
                        Console.WriteLine(" ");
                        Console.ReadKey();
                        Console.Clear();
                        break;
                    case 6:
                        Console.WriteLine("--------------------------------");
                        Console.WriteLine("OPCION 6: ORDEN INVERSO VECTOR A");
                        Console.WriteLine("Antes de invertir: ");
                        foreach (var elemento in A)
                        {
                            Console.WriteLine(elemento);
                        }
                        for (int indiceDelExtremoIzquierdo = 0; indiceDelExtremoIzquierdo < A.Length / 2; indiceDelExtremoIzquierdo++)
                        {
                            int indiceDelExtremoDerecho = A.Length - indiceDelExtremoIzquierdo - 1;
                            int temporal = A[indiceDelExtremoDerecho];
                            A[indiceDelExtremoDerecho] = A[indiceDelExtremoIzquierdo];
                            A[indiceDelExtremoIzquierdo] = temporal;
                        }

                        Console.WriteLine("Después de invertir: ");
                        foreach (var elemento in A)
                        {
                            Console.WriteLine(elemento);
                        }
                        Console.ReadKey();
                        Console.Clear();
                        break;
                    case 7:
                        SubMenu();
                        Console.ReadKey();
                        Console.Clear();


                        break;
                    case 8:

                        Console.WriteLine("Programa finalizado");
                    break;


                }
            } while (opcion != 8);
        }

        public void SubMenu() 
        {
            int opcion;
            do
            {

                Console.WriteLine("--------------------------------------");
                Console.WriteLine("---------> Escoga una de las opciones:");

                Console.WriteLine("1- MOSTRAR EL VECTOR A");
                Console.WriteLine("2- MOSTRAR EL VECTOR B");
                Console.WriteLine("3- MOSTRAR EL VECTOR C");
                Console.WriteLine("4- MOSTRAR EL VECTOR D");              
                Console.WriteLine("5- VOLVER AL MENU PRINCIPAL ");
                Console.WriteLine("--------------------------------------");
                Console.Write("Escoja una opción: ");
                 opcion = int.Parse(Console.ReadLine());
                Console.Clear();

                switch (opcion)
                {
                    case 1:
                        Console.WriteLine("OPCION 1: VECTOR A");
                        for (int i = 0; i < A.Length; i++)
                        {
                            Console.WriteLine((i + 1) + "." + A[i]);

                        }
                        Console.ReadKey();
                        Console.Clear();

                        break;
                    case 2:
                        Console.WriteLine("OPCION 1: VECTOR B");
                        for (int i = 0; i < B.Length; i++)
                        {
                            Console.WriteLine((i + 1) + "." + B[i]);

                        }
                        Console.ReadKey();
                        Console.Clear();

                        break;
                    case 3:
                        Console.WriteLine("OPCION 1: VECTOR C");
                        for (int i = 0; i < C.Length; i++)
                        {
                            Console.WriteLine((i + 1) + "." + C[i]);

                        }
                        Console.ReadKey();
                        Console.Clear();

                        break;
                    case 4:
                        Console.WriteLine("OPCION 1: VECTOR D");
                        for (int i = 0; i < D.Length; i++)
                        {
                            Console.WriteLine((i + 1) + "." + D[i]);

                        }
                        Console.ReadKey();
                        Console.Clear();
                        break;

                    case 5:


                        




                    default:
                        break;
                }

            } while (opcion != 5);
        
        }
    }
}



